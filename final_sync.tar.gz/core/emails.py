from django.core.mail import send_mail
from django.conf import settings
import threading
import json
import os
from datetime import date
import django.utils.timezone

# Reuse the counter logic from reservations to maintain the daily limit globally
# We'll use a shared counter file in the root media or somewhere accessible
_COUNTER_FILE = os.path.join(settings.BASE_DIR, 'media', '.global_email_counter.json')
_counter_lock = threading.Lock()

def _get_daily_count():
    try:
        with open(_COUNTER_FILE, 'r') as f:
            data = json.load(f)
        if data.get('date') == str(date.today()):
            return data.get('count', 0)
    except:
        pass
    return 0

def _increment_daily_count():
    today = str(date.today())
    try:
        if not os.path.exists(os.path.dirname(_COUNTER_FILE)):
            os.makedirs(os.path.dirname(_COUNTER_FILE))
            
        with open(_COUNTER_FILE, 'r') as f:
            data = json.load(f)
        if data.get('date') != today:
            data = {'date': today, 'count': 0}
    except:
        data = {'date': today, 'count': 0}
        
    data['count'] += 1
    with open(_COUNTER_FILE, 'w') as f:
        json.dump(data, f)
    return data['count']

def _log_event(msg):
    log_file = os.path.join(settings.BASE_DIR, 'media', 'core_email_debug.log')
    try:
        timestamp = django.utils.timezone.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"[{timestamp}] {msg}\n")
    except:
        pass

def _safe_email(to_list, subject, html_body):
    if not to_list or not any(to_list):
        return

    daily_limit = getattr(settings, 'EMAIL_DAILY_LIMIT', 200)

    def _send():
        with _counter_lock:
            current = _get_daily_count()
            if current >= daily_limit:
                _log_event(f"[BLOQUEADO] Límite diario ({daily_limit}) alcanzado. No se envió: {subject}")
                return
            new_count = _increment_daily_count()

        try:
            send_mail(
                subject=subject,
                message='',
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[r for r in to_list if r],
                html_message=html_body,
                fail_silently=False,
            )
            _log_event(f"[SUCCESS] Enviado a {to_list} | {subject}")
        except Exception as e:
            _log_event(f"[ERROR] Falló envío a {to_list}: {str(e)}")

    threading.Thread(target=_send, daemon=True).start()

def _base_template(titulo, contenido_html):
    return f"""
    <!DOCTYPE html>
    <html lang="es">
    <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
    <body style="margin:0;padding:0;background:#f8fafc;font-family:'Segoe UI',Arial,sans-serif;">
      <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;padding:32px 0;">
        <tr><td align="center">
          <table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:24px;overflow:hidden;box-shadow:0 10px 40px rgba(0,0,0,0.05);border:1px solid #e2e8f0;">
            <!-- HEADER -->
            <tr>
              <td style="background:#1e293b;padding:32px;text-align:center;">
                <p style="margin:0;color:#94a3b8;font-size:11px;font-weight:700;letter-spacing:3px;text-transform:uppercase;">SLEP Iquique · Sistema de Gestión</p>
                <h1 style="margin:12px 0 0;color:#fff;font-size:24px;font-weight:900;">{titulo}</h1>
              </td>
            </tr>
            <!-- BODY -->
            <tr>
              <td style="padding:40px;background:#ffffff;">
                {contenido_html}
              </td>
            </tr>
            <!-- FOOTER -->
            <tr>
              <td style="background:#f8fafc;padding:24px 32px;border-top:1px solid #e2e8f0;text-align:center;">
                <p style="margin:0;color:#94a3b8;font-size:12px;line-height:1.6;">
                  Este es un mensaje automático del Sistema SGAF.<br>
                  © {date.today().year} Servicio Local de Educación Pública Iquique
                </p>
              </td>
            </tr>
          </table>
        </td></tr>
      </table>
    </body>
    </html>
    """

def enviar_correo_reset_password(email, nombre, reset_url):
    subject = "🔑 Restablecer tu contraseña - SGAF"
    contenido = f"""
    <p style="color:#475569;font-size:16px;margin:0 0 24px;">Hola <strong>{nombre}</strong>,</p>
    <p style="color:#64748b;font-size:15px;line-height:1.6;margin:0 0 32px;">
        Hemos recibido una solicitud para restablecer la contraseña de tu cuenta en el Sistema de Gestión del SLEP Iquique. 
        Si no realizaste esta solicitud, puedes ignorar este mensaje de forma segura.
    </p>
    
    <div style="text-align:center;margin:40px 0;">
        <a href="{reset_url}" style="background:#2563eb;color:#ffffff;padding:16px 32px;border-radius:16px;text-decoration:none;font-size:15px;font-weight:700;display:inline-block;box-shadow:0 4px 12px rgba(37,99,235,0.2);transition:all 0.3s;">
            Restablecer Contraseña Ahora
        </a>
    </div>

    <div style="background:#f1f5f9;border-radius:16px;padding:24px;border:1px solid #e2e8f0;">
        <p style="margin:0 0 12px;color:#475569;font-size:13px;font-weight:700;">¿El botón no funciona?</p>
        <p style="margin:0;color:#64748b;font-size:12px;word-break:break-all;">
            Copia y pega este enlace en tu navegador:<br>
            <a href="{reset_url}" style="color:#2563eb;text-decoration:none;">{reset_url}</a>
        </p>
    </div>

    <p style="color:#94a3b8;font-size:13px;margin:32px 0 0;text-align:center;">
        Este enlace expirará en 24 horas por motivos de seguridad.
    </p>
    """
    body = _base_template("Recuperación de Cuenta", contenido)
    _safe_email([email], subject, body)
